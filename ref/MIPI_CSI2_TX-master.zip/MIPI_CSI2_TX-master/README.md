# MIPI_CSI2_TX
VHDL code for using Xilinx MGT gigabit transceivers/LVDS lines for MIPI CSI-2 TX  protocol.

Copyright: free for non-commercial use. Please contact michael@videogpu.com for commercial licence.
