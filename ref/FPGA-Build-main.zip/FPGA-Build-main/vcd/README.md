This folder contains all the waveforms of the RTL simulation of the design files

To display a waveform,
  + Change the working directory to FPGA-Build/vcd
  + Run gtkwave vcd_filename.vcd
  + Expand the module elements in the left sidebar to view each register, wire and i/o ports of that module
  + Double click on a signal to display it on the graph
