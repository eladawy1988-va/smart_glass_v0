This folder contains a set of module templates that is used accross all the design files.
